import java.util.ArrayList;
import java.util.Iterator;
import java.util.Scanner;

public class InventarioPapeleria {
    private ArrayList(Producto) inventario = new ArrayList (Producto);

    public InventarioPapeleria() {
    }

    public void agregarProducto(String var1, double var2, int var4) {
        this.inventario.add(new Producto(var1, var2, var4));
        System.out.println("Producto agregado: " + var1);
    }

    public void retirarProducto(String var1, int var2) {
        Iterator var3 = this.inventario.iterator();

        Producto var4;
        do {
            if (!var3.hasNext()) {
            System.out.println("Producto no encontrado: " + var1);
            return;
            }

        var4 = (Producto)var3.next();
        } while(!var4.descripcion.equals(var1));

        if (var4.cantidad >= var2) {
            var4.cantidad -= var2;
            System.out.println("Retirado: " + var2 + " de " + var1);
        } else {
            System.out.println("No hay suficiente cantidad de " + var1);
        }
    }

    public void mostrarInventario() {
        System.out.println("Inventario actual:");
        Iterator var1 = this.inventario.iterator();

        while(var1.hasNext()) {
            Producto var2 = (Producto)var1.next();
            System.out.println(var2);
        } 

    }    

    public static void main(String[] var0) {
        Scanner var1 = new Scanner(System.in);
        InventarioPapeleria var2 = new InventarioPapeleria();

        int var3;
        do {
            System.out.println("\nMenu:");
            System.out.println("1. Agregar producto");
            System.out.println("2. Retirar producto");
            System.out.println("3. Mostrar inventario");
            System.out.println("4. Salir");
            System.out.print("Seleccione una opci\u00f3n: ");
            var3 = var1.nextInt();
            var1.nextLine();
            switch (var3) {
            case 1:
                System.out.print("Descripci\u00f3n del producto: ");
                String var4 = var1.nextLine();
                System.out.print("Precio del producto: ");
                double var5 = var1.nextDouble();
                System.out.print("Cantidad del producto: ");
                int var7 = var1.nextInt();
                var2.agregarProducto(var4, var5, var7);
                break;
            case 2:
                System.out.print("Descripci\u00f3n del producto a retirar: ");
                String var8 = var1.nextLine();
                System.out.print("Cantidad a retirar: ");
                int var9 = var1.nextInt();
                var2.retirarProducto(var8, var9);
                break;
            case 3:
                var2.mostrarInventario();
                break;
            case 4:
                System.out.println("Saliendo...");
                break;
            default:
                System.out.println("Opci\u00f3n no v\u00e1lida. Intente de nuevo.");
            }
        } while(var3 != 4);

        var1.close();
    }
}
