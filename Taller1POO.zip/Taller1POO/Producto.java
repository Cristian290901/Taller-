public class Producto {
    String descripcion;
    double precio;       
    int cantidad;
    
    public Producto(String var1, double var2, int var4) {
        this.descripcion = var1;
        this.precio = var2;
        this.cantidad = var4;
    }
    
    public String toString() {
    return "Descripci\u00f3n: " + this.descripcion + ", Precio: " + this.precio + ", Cantidad: " + this.cantidad;
    }
}